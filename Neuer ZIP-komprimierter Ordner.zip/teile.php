<?php
$ausgabe = '';


// ------------ DB abfragen ---------------------------------------------------------
require('db_connect.php');

$sql='SELECT * FROM teile';

foreach($pdo->query($sql) as $row) {
	
	$ausgabe .= '
	<div style="background-color:#cccccc; padding: 5%; margin-bottom:5%;">
		<form name="" id="" action="" method="post">
			<input type="hidden" id="todo" name="todo" value="update">
			<input type="hidden" id="welcheid" name="welcheid" value="'.$row['teileid'].'">

			  <div class="form-group">
				<label for="Bezeichnung">Bezeichnung</label>
				<input type="text" class="form-control" id="bezeichnung" name="bezeichnung" aria-describedby="" value="'.utf8_encode($row['bezeichnung']).'">
			  </div>
			  
			  <div class="form-group">
				<label for="Preis">Preis</label>
				<input type="text" class="form-control" id="preis" name="preis" aria-describedby="" value="'.utf8_encode($row['preis']).'">
			  </div>
			  
			  <button type="submit" class="btn btn-primary">speichern</button>
			  	  
		</form>
		<form name="" id="" action="" method="post">
			<input type="hidden" id="todo" name="todo" value="loeschen">
			<input type="hidden" id="welcheid" name="welcheid" value="'.$row['teileid'].'">			
			<button type="submit" class="btn btn-primary">X</button>
		</form>

	</div>
	';
}

// -----------------------------------------------------------------------------------






// neu eintragen ------------------------------------------------------------------------------

if (count($_POST)) {
	if ($_POST['todo'] == 'eintragen_teile') {
	
	$bezeichnung = 		$_POST['bezeichnung'];
	$preis = 			$_POST['preis'];

	
	
	// ------------ DB DS einfügen ---------------------------------------------------------

	require('db_connect.php');

	$statement = $pdo->prepare('INSERT INTO teile (bezeichnung, preis) VALUES (?, ?)');

	$statement->execute(array("".$bezeichnung."", "".$preis.""));

	// -----------------------------------------------------------------------------------

	
	echo '<meta http-equiv="refresh" content="0">';

	
	}
}






// update ------------------------------------------------------------------------------

if (count($_POST)) {
	if ($_POST['todo'] == 'update') {
		
	// ------------ DB DS einfügen ---------------------------------------------------------

	require('db_connect.php');

	$sql = '
		UPDATE teile 
		
		SET bezeichnung= "'.$_POST['bezeichnung'].'",
			preis= "'.$_POST['preis'].'"
		
		WHERE teileid = '.$_POST['welcheid'].'
	';
			
	$statement = $pdo->prepare($sql);
	$statement->execute();

	// -----------------------------------------------------------------------------------
	echo '<meta http-equiv="refresh" content="0">';
	}
}



// ========== LÖSCHEN =============

if (count($_POST)) {
	//print_r($_POST);

	if ($_POST['todo'] == 'loeschen') {
	
	$id = $_POST['welcheid'];
	
	echo 'Wollen Sie den Datensatz '.$id.' wirklich löschen?
		<form name="" id="" method="post">
			<input type="hidden" name="todo" id="todo" value="wirklich_loeschen">
			<input type="hidden" name="id" id="id" value="'.$id.'"> 
			<input type="submit" value="JA">
		</form>
	';

	echo '
		<form name="aktualisieren" id="aktualisieren" method="post">
			<input type="submit" value="NEIN">
		</form>
	';
	
	}
}



// ========== LÖSCHEN II =============

if (count($_POST)) {
	if ($_POST['todo'] == 'wirklich_loeschen') {
	
	$id = $_POST['id'];
	

	
	// --------------------------------------------------------------------

	require('db_connect.php');

	$statement = $pdo->prepare('DELETE FROM teile WHERE teileid = ?');

	$statement->execute(array($id));

	// -----------------------------------------------------------------------------------

	echo '<meta http-equiv="refresh" content="0">';	
				
	}
}



	






if (count($_POST)) {
	//print_r($_POST);

	if ($_POST['todo'] == 'aktualisieren') {
	
	echo '<meta http-equiv="refresh" content="0">';		
	}
}




$button_aktualisieren = '
	<form name="aktualisieren" id="aktualisieren" method="post">
		<input type="submit" value="Seite aktualisieren">
	</form>
';




?>

<?php include('head.php'); ?>

<?php include('navigation.php'); ?>




<div class="formulare">
	<form name="" id="" action="" method="post">
		<input type="hidden" id="todo" name="todo" value="eintragen_teile">		

	
	<h1>Neuen Artikel eintragen</h1>

	
	  <div class="form-group">
		<label for="Bezeichnung">Bezeichnung</label>
		<input type="text" class="form-control" id="bezeichnung" name="bezeichnung" aria-describedby="" placeholder="">
	  </div>
	  
	  <div class="form-group">
		<label for="Preis">Preis</label>
		<input type="number" step="0.01" class="form-control" id="preis" name="preis" aria-describedby="" placeholder="">
	  </div>
	  
	  <button type="submit" class="btn btn-primary">eintragen</button>
	  
	</form>
</div>



<hr>



<div class="formulare">


<h1>Bestehende Artikel verwalten</h1>


<?php
echo $ausgabe;	
?>
</div>




</body>
</html>