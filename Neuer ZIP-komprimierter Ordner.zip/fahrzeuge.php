<?php
$ausgabe = '';


// ------------ DB abfragen bestehende Fahrzeuge---------------------------------------------------------
require('db_connect.php');

$sql='SELECT * FROM fahrzeug';

foreach($pdo->query($sql) as $row) {
	
	$ausgabe .= '
	<div style="background-color:#ccc; padding:10%;"
		<form name="aaa" id="aaa" action="" method="post">
			<input type="hidden" id="todo" name="todo" value="fzupdate">		


			  <div class="form-group">
				<label for="Marke">Marke</label>
				<input type="text" class="form-control" id="marke" name="marke" aria-describedby="" value="'.$row['marke'].'">
			  </div>
			  
			  <div class="form-group">
				<label for="Fahrzeug">Fahrzeug-ID</label>
				<input type="text" class="form-control" id="fzid" name="fzid" aria-describedby="" value="'.$row['fzid'].'">
			  </div>	  
			  
				  <div class="form-group">
				<label for="type">Type</label>
				<input type="text" class="form-control" id="type" name="type" aria-describedby="" value="'.$row['type'].'">
			  </div>  
			  
			  <div class="form-group">
				<label for="kennzeichen">Kennzeichen</label>
				<input type="text" class="form-control" id="kennzeichen" name="kennzeichen" aria-describedby="" value="'.$row['kennzeichen'].'">
			  </div>	  
			  
			  <div class="form-group">
				<label for="fahrgestellnummer">Fahrgestellnummer</label>
				<input type="text" class="form-control" id="fahrgestellnummer" name="fahrgestellnummer" aria-describedby="" value="'.$row['fahrgestellnummer'].'">
			  </div>	  
			  
			  <div class="form-group">
				<label for="nationalcode">Nationalcode</label>
				<input type="text" class="form-control" id="nationalcode" name="nationalcode" aria-describedby="" value="'.$row['nationalcode'].'">
			  </div>	  

			  <div class="form-group">
				<label for="Motorkennzeichen">Motorkennzeichen</label>
				<input type="text" class="form-control" id="motorkennzeichen" name="motorkennzeichen" aria-describedby="" value="'.$row['motorkennzeichen'].'">
			  </div>

			  <div class="form-group">
				<label for="Getriebekennzeichen">Getriebekennzeichen</label>
				<input type="text" class="form-control" id="getriebekennzeichen" name="getriebekennzeichen" aria-describedby="" value="'.$row['getriebekennzeichen'].'">
			  </div>
			  
			  <div class="form-group">
				<label for="Farbe">Farbe</label>
				<input type="text" class="form-control" id="farbe" name="farbe" aria-describedby="" value="'.$row['farbe'].'">
			  </div>	  
			  
			  <div class="form-group">
				<label for="Treibstoff">Treibstoff</label>
				<input type="text" class="form-control" id="treibstoff" name="treibstoff" aria-describedby="" value="'.$row['treibstoff'].'">
			  </div>	  
			
			  <div class="form-group">
				<label for="Leistung">Leistung</label>
				<input type="number" class="form-control" id="leistung" name="leistung" aria-describedby="" value="'.$row['leistung'].'">
			  </div>	

			  <div class="form-group">
				<label for="Hubraum">Hubraum</label>
				<input type="number" class="form-control" id="hubraum" name="hubraum" aria-describedby="" value="'.$row['hubraum'].'">
			  </div>	
			
			  <div class="form-group">
				<label for="Erstzulassung">Erstzulassung</label>
				<input type="date" class="form-control" id="erstzulassung" name="erstzulassung" aria-describedby="" value="'.$row['erstzulassung'].'">
			  </div>	
		  
		  <button type="submit" class="btn btn-primary">aktualisieren</button>
		  
		</form>	
		<form name="" id="" method="post">
			<button type="submit" class="btn btn-primary">loeschen</button>
			<input type="hidden" id="todo" name="todo" value="loeschen">		
			<input type="hidden" id="fzid" name="fzid" value="'.utf8_encode($row['fzid']).'">						
		</form>			
	</div>
	<hr>
	';

}

// -----------------------------------------------------------------------------------






// neu eintragen ------------------------------------------------------------------------------

if (count($_POST)) {
	if ($_POST['todo'] == 'eintragen_fz') {

	// ------------ DB DS einfügen ---------------------------------------------------------

	require('db_connect.php');

	$statement = $pdo->prepare('INSERT INTO fahrzeug (marke, type, kennzeichen, fahrgestellnummer, nationalcode, motorkennzeichen, getriebekennzeichen, farbe, treibstoff, leistung, hubraum, erstzulassung) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');

	$statement->execute(array("".$_POST['marke']."", "".$_POST['type']."", "".$_POST['kennzeichen']."", "".$_POST['fahrgestellnummer']."", "".$_POST['nationalcode']."", "".$_POST['motorkennzeichen']."", "".$_POST['getriebekennzeichen']."", "".$_POST['farbe']."", "".$_POST['treibstoff']."", "".$_POST['leistung']."", "".$_POST['hubraum']."", "".$_POST['erstzulassung'].""));

	// -----------------------------------------------------------------------------------
	
	echo '<meta http-equiv="refresh" content="0">';
	}
}




// ========== LÖSCHEN =============

if (count($_POST)) {
	//print_r($_POST);

	if ($_POST['todo'] == 'loeschen') {
	
	$id = $_POST['fzid'];
	
	echo 'Wollen Sie den Datensatz '.$id.' wirklich löschen?
		<form name="" id="" method="post">
			<input type="hidden" name="todo" id="todo" value="wirklich_loeschen">
			<input type="hidden" name="id" id="id" value="'.$id.'"> 
			<input type="submit" value="JA">
		</form>
	';

	echo '
		<form name="aktualisieren" id="aktualisieren" method="post">
			<input type="submit" value="NEIN">
		</form>
	';
	
	}
}



// ========== LÖSCHEN II =============

if (count($_POST)) {
	if ($_POST['todo'] == 'wirklich_loeschen') {
	
	$id = $_POST['id'];
	

	
	// --------------------------------------------------------------------

	require('db_connect.php');

	$statement = $pdo->prepare('DELETE FROM fahrzeug WHERE fzid = ?');

	$statement->execute(array($id));

	// -----------------------------------------------------------------------------------

	
	echo '<meta http-equiv="refresh" content="0">';	
	
				
	}
}





// ------------------------- bestehendes fz update -----------------------------------

if (count($_POST)) {
	if ($_POST['todo'] == 'fzupdate') {
		
	// ------------ DB DS einfügen ---------------------------------------------------------

	require('db_connect.php');

	$sql = '
		UPDATE fahrzeug 
		
		SET marke = "'.$_POST['marke'].'",
			fzid = "'.$_POST['fzid'].'",
			type = "'.$_POST['type'].'",
			vorname = "'.$_POST['kennzeichen'].'",
			nachname = "'.$_POST['fahrgestellnummer'].'",
			gebdat = "'.$_POST['nationalcode'].'",
			strasse = "'.$_POST['motorkennzeichen'].'",
			plz = "'.$_POST['getriebekennzeichen'].'",
			ort = "'.$_POST['treibstoff'].'",
			telefon = "'.$_POST['leistung'].'",
			email = "'.$_POST['hubraum'].'",
			newsletter = "'.$_POST['erstzulassung'].'"
		
		WHERE fzid = '.$_POST['fzid'].'
	';
			
	$statement = $pdo->prepare($sql);
	$statement->execute();

	// -----------------------------------------------------------------------------------
	echo '<meta http-equiv="refresh" content="0">';
	}
}









if (count($_POST)) {
	//print_r($_POST);

	if ($_POST['todo'] == 'aktualisieren') {
	
	echo '<meta http-equiv="refresh" content="0">';		
	}
}




$button_aktualisieren = '
	<form name="aktualisieren" id="aktualisieren" method="post">
		<input type="submit" value="Seite aktualisieren">
	</form>
';




?>

<?php include('head.php'); ?>

<?php include('navigation.php'); ?>




<div class="formulare">
	<form name="aa" id="aa" action="" method="post">
		<input type="hidden" id="todo" name="todo" value="eintragen_fz">		

	
	<h1>Neues Kundenfahrzeug eintragen</h1>  
	  
	  <div class="form-group">
		<label for="Marke">Marke</label>
		<input type="text" class="form-control" id="marke" name="marke" aria-describedby="" placeholder="">
	  </div>	  
	  
		  <div class="form-group">
		<label for="Type">Type</label>
		<input type="text" class="form-control" id="type" name="type" aria-describedby="" placeholder="">
	  </div>  
	  
	  <div class="form-group">
		<label for="Kennzeichen">Kennzeichen</label>
		<input type="text" class="form-control" id="kennzeichen" name="kennzeichen" aria-describedby="" placeholder="">
	  </div>	  
	  
	  <div class="form-group">
		<label for="Fahrgestellnummer">Fahrgestellnummer</label>
		<input type="text" class="form-control" id="fahrgestellnummer" name="fahrgestellnummer" aria-describedby="" placeholder="">
	  </div>	  
	  
	  <div class="form-group">
		<label for="Nationalcode">Nationalcode</label>
		<input type="text" class="form-control" id="nationalcode" name="nationalcode" aria-describedby="" placeholder="">
	  </div>	  

	  <div class="form-group">
		<label for="Motorkennzeichen">Motorkennzeichen</label>
		<input type="text" class="form-control" id="motorkennzeichen" name="motorkennzeichen" aria-describedby="" placeholder="">
	  </div>

	  <div class="form-group">
		<label for="Getriebekennzeichen">Getriebekennzeichen</label>
		<input type="text" class="form-control" id="getriebekennzeichen" name="getriebekennzeichen" aria-describedby="" placeholder="">
	  </div>
	  
	  <div class="form-group">
		<label for="Farbe">Farbe</label>
		<input type="text" class="form-control" id="farbe" name="farbe" aria-describedby="" placeholder="">
	  </div>	  
	  
	  <div class="form-group">
		<label for="treibstoff">Treibstoff</label>
		<input type="text" class="form-control" id="treibstoff" name="treibstoff" aria-describedby="" placeholder="">
	  </div>	  
	
	  <div class="form-group">
		<label for="leistung">Leistung</label>
		<input type="text" class="form-control" id="leistung" name="leistung" aria-describedby="" placeholder="">
	  </div>	

	  <div class="form-group">
		<label for="hubraum">Hubraum</label>
		<input type="number" class="form-control" id="hubraum" name="hubraum" aria-describedby="" placeholder="">
	  </div>	
	
	  <div class="form-group">
		<label for="erstzulassung">Erstzulassung</label>
		<input type="date" class="form-control" id="erstzulassung" name="erstzulassung" aria-describedby="" placeholder="">
	  </div>	

	  
	  
	  <button type="submit" class="btn btn-primary">eintragen</button>
	  
	</form>
</div>


<hr>


<div class="formulare">
	<h1>Bestehende Kundenfahrzeuge</h1>
	<?php echo $ausgabe; ?>
</div>




</body>
</html>