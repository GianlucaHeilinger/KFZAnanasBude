<div style="background-color:#ccc; padding:10%; padding-top:3%; padding-bottom:3%;">

	<h1>KFZ Werkstatt Verwaltung</h1>

	<a style="margin:3px;" href="index.php"><button type="button" class="btn btn-primary">Hauptmenü</button></a>
	
	<br /><br />	
	
	<a style="margin:3px;" href="kunden.php"><button type="button" class="btn btn-primary">Kunden Verwaltung</button></a>
	
	<a style="margin:3px;" href="fahrzeuge.php"><button type="button" class="btn btn-primary">Kundenfahrzeuge Verwaltung</button></a>
	
	<br /><br />

	<a style="margin:3px;" href="teile.php"><button type="button" class="btn btn-primary">Teile Verwaltung</button></a>

	<a style="margin:3px;" href="reparatur.php"><button type="button" class="btn btn-primary">Reparaturauftrag Verwaltung</button></a>

	<a style="margin:3px;" href="rechnung.php"><button type="button" class="btn btn-primary">Rechnungen Verwaltung</button></a>


	
</div>