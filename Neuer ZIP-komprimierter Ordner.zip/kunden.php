<?php
$ausgabe = '';




// ------------ bestehende Kunden auslesen ---------------------------------------------------------
require('db_connect.php');

$sql='SELECT * FROM kunde';

foreach($pdo->query($sql) as $row) {
	
	$ausgabe .= '
	<div style="background-color:#ccc; padding:10%;">			
		<form name="" id="" method="post" action="">
			<input type="hidden" id="todo" name="todo" value="update">		

			<div class="form-group">
				<label for="kundennummer">Kundennummer: </label>
				<input type="number"  min="1" max="99999" class="form-control" id="kundennummer" name="kundennummer" value="'.utf8_encode($row['kundennummer']).'">
			</div>
			
			<div class="form-group">
				<label for="anrede">Anrede: </label>
				<input type="text" class="form-control" id="anrede" name="anrede" value='.utf8_encode($row['anrede']).'>
			</div>		
			
			<div class="form-group">
				<label for="titel">Titel: </label>
				<input type="text" class="form-control" id="titel" name="titel" value="'.utf8_encode($row['titel']).'">
			</div>		
			
			<div class="form-group">
				<label for="vorname">Vorname: </label>
				<input type="text" class="form-control" id="vorname" name="vorname" value="'.utf8_encode($row['vorname']).'">
			</div>
			
			<div class="form-group">
				<label for="nachname">Nachname: </label>
				<input type="text" class="form-control" id="nachname" name="nachname" value="'.utf8_encode($row['nachname']).'">
			</div>			
			
			<div class="form-group">
				<label for="gebdat">Geburtsdatum: </label>
				<input type="date" class="form-control" id="gebdat" name="gebdat" value="'.utf8_encode($row['gebdat']).'">
			</div>	

			<div class="form-group">
				<label for="strasse">Strasse: </label>
				<input type="text" class="form-control" id="strasse" name="strasse" value="'.utf8_encode($row['strasse']).'">
			</div>
			
			<div class="form-group">
				<label for="plz">PLZ: </label>
				<input type="text" class="form-control" id="plz" name="plz" value="'.utf8_encode($row['plz']).'">
			</div>		

			<div class="form-group">
				<label for="ort">Ort: </label>
				<input type="text" class="form-control" id="ort" name="ort" value="'.utf8_encode($row['ort']).'">
			</div>

			<div class="form-group">
				<label for="telefon">Telefon: </label>
				<input type="text" class="form-control" id="telefon" name="telefon" value="'.utf8_encode($row['telefon']).'">
			</div>

			<div class="form-group">
				<label for="email">E-Mail: </label>
				<input type="text" class="form-control" id="email" name="email" value="'.utf8_encode($row['email']).'">
			</div>
			
			<div class="form-group">
				<label for="newsletter">Newsletter: </label>
				<input type="number" class="form-control" id="newsletter" name="newsletter" value="'.utf8_encode($row['newsletter']).'">
			</div>

			<div class="form-group">
				<label for="kommentar">Kommentar: </label>
				<input type="text" class="form-control" id="kommentar" name="kommentar" value="'.utf8_encode($row['kommentar']).'">
			</div>

			<div class="form-group">
				<label for="kundeseit">Kunde seit: </label>
				<input type="date" class="form-control" id="kundeseit" name="kundeseit" value="'.utf8_encode($row['kundeseit']).'">
			</div>		
			

			<button type="submit" class="btn btn-primary">update</button>
		</form>
		<form name="" id="" method="post">
			<button type="submit" class="btn btn-primary">loeschen</button>
			<input type="hidden" id="todo" name="todo" value="loeschen">		
			<input type="hidden" id="kundennummer" name="kundennummer" value="'.utf8_encode($row['kundennummer']).'">						
		</form>
	</div>
	<hr>
	';
}

// -----------------------------------------------------------------------------------



// ------------------------- bestehende KD update -----------------------------------

if (count($_POST)) {
	if ($_POST['todo'] == 'update') {
		
	// ------------ DB DS einfügen ---------------------------------------------------------

	require('db_connect.php');

	$sql = '
		UPDATE kunde 
		
		SET kundennummer = "'.$_POST['kundennummer'].'",
			anrede = "'.$_POST['anrede'].'",
			titel = "'.$_POST['titel'].'",
			vorname = "'.$_POST['vorname'].'",
			nachname = "'.$_POST['nachname'].'",
			gebdat = "'.$_POST['gebdat'].'",
			strasse = "'.$_POST['strasse'].'",
			plz = "'.$_POST['plz'].'",
			ort = "'.$_POST['ort'].'",
			telefon = "'.$_POST['telefon'].'",
			email = "'.$_POST['email'].'",
			newsletter = "'.$_POST['newsletter'].'",
			kommentar = "'.$_POST['kommentar'].'",
			kundeseit = "'.$_POST['kundeseit'].'"
		
		WHERE kundennummer = '.$_POST['kundennummer'].'
	';
			
	$statement = $pdo->prepare($sql);
	$statement->execute();

	// -----------------------------------------------------------------------------------
	echo '<meta http-equiv="refresh" content="0">';
	}
}




// ------------------------------- neuer KD eintragen --------------------------------------------
if (count($_POST)) {
	if ($_POST['todo'] == 'eintragen') {
	
	$kundennummer = 		$_POST['kundennummer'];
	$anrede = 				$_POST['anrede'];
	$titel = 				$_POST['titel'];
	$vorname = 				$_POST['vorname'];
	$nachname = 			$_POST['nachname'];
	$gebdat = 				$_POST['gebdat'];
	$strasse = 				$_POST['strasse'];
	$plz = 					$_POST['plz'];
	$ort = 					$_POST['ort'];
	$telefon = 				$_POST['telefon'];
	$email = 				$_POST['email'];
	$newsletter = 			$_POST['newsletter'];
	$kommentar = 			$_POST['kommentar'];
	$kundeseit = 			$_POST['kundeseit'];

	
	
	
	
	// ------------ DB DS einfügen ---------------------------------------------------------

	require('db_connect.php');

	$statement = $pdo->prepare('INSERT INTO kunde (kundennummer, anrede, titel, vorname, nachname, gebdat, strasse, plz, ort, telefon, email, newsletter, kommentar, kundeseit) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');

	$statement->execute(array("".$kundennummer."", "".$anrede."", "".$titel."", "".$vorname."", "".$nachname."", "".$gebdat."", "".$strasse."", "".$plz."", "".$ort."", "".$telefon."", "".$email."", "".$newsletter."", "".$kommentar."", "".$kundeseit.""));

	// -----------------------------------------------------------------------------------

	
	echo '<meta http-equiv="refresh" content="0">';

	
	}
}



// ========== LÖSCHEN =============

if (count($_POST)) {
	//print_r($_POST);

	if ($_POST['todo'] == 'loeschen') {
	
	$id = $_POST['kundennummer'];
	
	echo 'Wollen Sie den Datensatz '.$id.' wirklich löschen?
		<form name="" id="" method="post">
			<input type="hidden" name="todo" id="todo" value="wirklich_loeschen">
			<input type="hidden" name="id" id="id" value="'.$id.'"> 
			<input type="submit" value="JA">
		</form>
	';

	echo '
		<form name="aktualisieren" id="aktualisieren" method="post">
			<input type="submit" value="NEIN">
		</form>
	';
	
	}
}



// ========== LÖSCHEN II =============

if (count($_POST)) {
	if ($_POST['todo'] == 'wirklich_loeschen') {
	
	$id = $_POST['id'];
	

	
	// --------------------------------------------------------------------

	require('db_connect.php');

	$statement = $pdo->prepare('DELETE FROM kunde WHERE kundennummer = ?');

	$statement->execute(array($id));

	// -----------------------------------------------------------------------------------

	
	echo '<meta http-equiv="refresh" content="0">';	
	
				
	}
}



	






if (count($_POST)) {
	//print_r($_POST);

	if ($_POST['todo'] == 'aktualisieren') {
	
	echo '<meta http-equiv="refresh" content="0">';		
	}
}




$button_aktualisieren = '
	<form name="aktualisieren" id="aktualisieren" method="post">
		<input type="submit" value="Seite aktualisieren">
	</form>
';




?>

<?php include('head.php'); ?>

<?php include('navigation.php'); ?>


<div class="formulare">
	<h1>Neuen Kunden eintragen</h1>

	
	<form name="" id="" method="post" action="">
		<input type="hidden" id="todo" name="todo" value="eintragen">		

		<div class="form-group">
			<label for="kundennummer">Kundennummer: </label>
			<input type="number"  min="1" max="99999" class="form-control" id="kundennummer" name="kundennummer" placeholder="">
		</div>
		
		<div class="form-group">
			<label for="anrede">Anrede: </label>
			<input type="text" class="form-control" id="anrede" name="anrede" placeholder="">
		</div>		
		
		<div class="form-group">
			<label for="titel">Titel: </label>
			<input type="text" class="form-control" id="titel" name="titel" placeholder="">
		</div>		
		
		<div class="form-group">
			<label for="vorname">Vorname: </label>
			<input type="text" class="form-control" id="vorname" name="vorname" placeholder="">
		</div>
		
		<div class="form-group">
			<label for="nachname">Nachname: </label>
			<input type="text" class="form-control" id="nachname" name="nachname" placeholder="">
		</div>			
		
		<div class="form-group">
			<label for="gebdat">Geburtsdatum: </label>
			<input type="date" class="form-control" id="gebdat" name="gebdat" placeholder="">
		</div>	

		<div class="form-group">
			<label for="strasse">Strasse: </label>
			<input type="text" class="form-control" id="strasse" name="strasse" placeholder="">
		</div>
		
		<div class="form-group">
			<label for="plz">PLZ: </label>
			<input type="text" class="form-control" id="plz" name="plz" placeholder="">
		</div>		

		<div class="form-group">
			<label for="ort">Ort: </label>
			<input type="text" class="form-control" id="ort" name="ort" placeholder="">
		</div>

		<div class="form-group">
			<label for="telefon">Telefon: </label>
			<input type="text" class="form-control" id="telefon" name="telefon" placeholder="">
		</div>

		<div class="form-group">
			<label for="email">E-Mail: </label>
			<input type="text" class="form-control" id="email" name="email" placeholder="">
		</div>
		
		<div class="form-group">
			<label for="newsletter">Newsletter: </label>
			<input type="number" class="form-control" id="newsletter" name="newsletter" placeholder="">
		</div>

		<div class="form-group">
			<label for="kommentar">Kommentar: </label>
			<input type="text" class="form-control" id="kommentar" name="kommentar" placeholder="">
		</div>

		<div class="form-group">
			<label for="kundeseit">Kunde seit: </label>
			<input type="date" class="form-control" id="kundeseit" name="kundeseit" placeholder="">
		</div>		
		
		
	  <button type="submit" class="btn btn-primary">eintragen</button>
	</form>

</div>


<hr>


<div class="formulare">
<h1>Bestehende Kunden</h1>
<?php echo $ausgabe; ?>
</div>





</body>
</html>