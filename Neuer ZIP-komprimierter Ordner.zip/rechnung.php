<?php
$ausgabe = '';


// ------------ bestehende RG abfragen ----------------------------------------------------
require('db_connect.php');

$sql='SELECT * FROM rechnung';

foreach($pdo->query($sql) as $row) {
	
	/*
	$ausgabe .= $row['rechnungid'];
	$ausgabe .= $row['rechnungsnummer'];
	$ausgabe .= $row['rechnungsdatum'];
	$ausgabe .= $row['kundenid'];	
	$ausgabe .= $row['fahrzeugid'];
	$ausgabe .= $row['status'];
	*/
	
	
	$ausgabe .= '
		<div style="background-color:#ccc; padding:10%;">
			<form name="" id="" action="" method="post">
				<input type="hidden" id="todo" name="todo" value="eintragen_rechnung">		
	
			<h1>Bestehende Rechnung</h1>
			
			  <div class="form-group">
				<label for="rechnungid">rechnungid</label>
				<input type="text" class="form-control" id="rechnungid" name="rechnungid" aria-describedby="" value="'.$row['rechnungid'].'">
			  </div>
			  
			  <div class="form-group">
				<label for="rechnungsnummer">rechnungsnummer</label>
				<input type="text" class="form-control" id="rechnungsnummer" name="rechnungsnummer" aria-describedby="" value="'.$row['rechnungsnummer'].'">
			  </div>
			  
			  <div class="form-group">
				<label for="rechnungsdatum">rechnungsdatum</label>
				<input type="text" class="form-control" id="rechnungsdatum" name="rechnungsdatum" aria-describedby="" value="'.$row['rechnungsdatum'].'">
			  </div>			  
			  
			  <div class="form-group">
				<label for="kundenid">kundenid</label>
				<input type="text" class="form-control" id="kundenid" name="kundenid" aria-describedby="" value="'.$row['kundenid'].'">
			  </div>

			  <div class="form-group">
				<label for="fahrzeugid">fahrzeugid</label>
				<input type="text" class="form-control" id="fahrzeugid" name="fahrzeugid" aria-describedby="" value="'.$row['fahrzeugid'].'">
			  </div>

			  <div class="form-group">
				<label for="status">status</label>
				<input type="text" class="form-control" id="status" name="status" aria-describedby="" value="'.$row['status'].'">
			  </div>			  
			  
			  <button type="submit" class="btn btn-primary">aktualisieren</button>
			  
			</form>		
			<form name="" id="" method="post">
				<button type="submit" class="btn btn-primary">loeschen</button>
				<input type="hidden" id="todo" name="todo" value="loeschen">		
				<input type="hidden" id="rechnungid" name="rechnungid" value="'.utf8_encode($row['rechnungid']).'">						
			</form>					
		</div>
		<hr>
	';
}

// -----------------------------------------------------------------------------------
   






// -------------------------------- neu eintragen ----------------------------------------------

if (count($_POST)) {
	if ($_POST['todo'] == 'eintragen') {
	
	
	// ------------ DB DS einfügen ---------------------------------------------------------

	require('db_connect.php');

	$statement = $pdo->prepare('INSERT INTO rechnung (rechnungsnummer, rechnungsdatum, kundenid, fahrzeugid, status) VALUES (?, ?, ?, ?, ?)');

	$statement->execute(array("".$_POST['rechnungsnummer']."", "".$_POST['rechnungsdatum']."", "".$_POST['kundenid']."", "".$_POST['fahrzeugid']."", "".$_POST['status'].""));

	// -----------------------------------------------------------------------------------

	
	echo '<meta http-equiv="refresh" content="0">';

	
	}
}



// ========== LÖSCHEN =============

if (count($_POST)) {
	//print_r($_POST);

	if ($_POST['todo'] == 'loeschen') {
	
	$id = $_POST['kundennummer'];
	
	echo 'Wollen Sie den Datensatz '.$id.' wirklich löschen?
		<form name="" id="" method="post">
			<input type="hidden" name="todo" id="todo" value="wirklich_loeschen">
			<input type="hidden" name="id" id="id" value="'.$id.'"> 
			<input type="submit" value="JA">
		</form>
	';

	echo '
		<form name="aktualisieren" id="aktualisieren" method="post">
			<input type="submit" value="NEIN">
		</form>
	';
	
	}
}



// ========== LÖSCHEN II =============

if (count($_POST)) {
	if ($_POST['todo'] == 'wirklich_loeschen') {
	
	$id = $_POST['id'];
	

	
	// --------------------------------------------------------------------

	$pdo = new PDO("mysql:host=localhost;dbname=db_werkstatt_projekt","root","");

	$statement = $pdo->prepare('DELETE FROM kunde WHERE kundennummer = ?');

	$statement->execute(array($id));

	// -----------------------------------------------------------------------------------

	
	echo '<meta http-equiv="refresh" content="0">';	
	
				
	}
}



	






if (count($_POST)) {
	//print_r($_POST);

	if ($_POST['todo'] == 'aktualisieren') {
	
	echo '<meta http-equiv="refresh" content="0">';		
	}
}




$button_aktualisieren = '
	<form name="aktualisieren" id="aktualisieren" method="post">
		<input type="submit" value="Seite aktualisieren">
	</form>
';




?>

<?php include('head.php'); ?>

<?php include('navigation.php'); ?>




<div class="formulare">
	<form name="" id="" action="" method="post">
		<input type="hidden" id="todo" name="todo" value="eintragen">		

	<h1>Neue Rechnung erstellen</h1>
	  
	  <div class="form-group">
		<label for="rechnungsnummer">rechnungsnummer</label>
		<input type="text" class="form-control" id="rechnungsnummer" name="rechnungsnummer" aria-describedby="" value="">
	  </div>
	  
	  <div class="form-group">
		<label for="rechnungsdatum">rechnungsdatum</label>
		<input type="date" class="form-control" id="rechnungsdatum" name="rechnungsdatum" aria-describedby="" value="">
	  </div>			  
	  
	  <div class="form-group">
		<label for="kundenid">kundenid</label>
		<input type="text" class="form-control" id="kundenid" name="kundenid" aria-describedby="" value="">
	  </div>

	  <div class="form-group">
		<label for="fahrzeugid">fahrzeugid</label>
		<input type="text" class="form-control" id="fahrzeugid" name="fahrzeugid" aria-describedby="" value="">
	  </div>

	  <div class="form-group">
		<label for="status">status</label>
		<input type="text" class="form-control" id="status" name="status" aria-describedby="" value="">
	  </div>			  
	  
	  <button type="submit" class="btn btn-primary">eintragen</button>
	  
	</form>				
</div>







<div class="formulare">
<?php echo $ausgabe; ?>
</div>




</body>
</html>