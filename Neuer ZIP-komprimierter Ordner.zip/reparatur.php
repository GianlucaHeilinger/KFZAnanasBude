<?php
$ausgabe = '';
$kd = '';
$fz = '';



// ------------------------------- neuer Auftrag eintragen --------------------------------------------
if (count($_POST)) {
	if ($_POST['todo'] == 'eintragen') {
		
		print_r($_POST);
		
		$datum = 		$_POST['datum'];
		$teile = 		$_POST['teile'];
		$anzahl = 		$_POST['anzahl'];

		// ------------ DB DS einfügen ---------------------------------------------------------

		require('db_connect.php');

		$statement = $pdo->prepare('INSERT INTO reparaturdetails (repdetid, repid, ) VALUES (?, ?)');

		$statement->execute(array("".$datum."", "".$teile."", "".$anzahl.""));
		
			
			
		$statement = $pdo->prepare('INSERT INTO reparaturdetails, reparatur (datum, teileid, anzahl) VALUES (?, ?, ?)');

		$statement->execute(array("".$datum."", "".$teile."", "".$anzahl.""));		

		// -----------------------------------------------------------------------------------
		
		echo '<meta http-equiv="refresh" content="0">';
	}
}






// ------------------ bestehende Reparaturaufträge abfragen ----------------------------

require('db_connect.php');

$sql='SELECT * FROM reparaturdetails';

foreach($pdo->query($sql) as $row) {
	
	$ausgabe .= '
		<div style="background-color:#ccc; padding:10%;">
			<form name="" id="" action="" method="post">
				<input type="hidden" id="todo" name="todo" value="xxxxxx">		
		
			<h1>bestehende Reparaturaufträge abfragen</h1>
		  
			  <div class="form-group">
				<label for="repdetid">repdetid</label>
				<input type="text" class="form-control" id="repdetid" name="repdetid" value="'.$row['repdetid'].'">
			  </div>	  
			  
			  <div class="form-group">
				<label for="repid">repid</label>
				<input type="text" class="form-control" id="repid" name="repid" value="'.$row['repid'].'">
			  </div>

			  <div class="form-group">
				<label for="teileid">teileid</label>
				<input type="text" class="form-control" id="teileid" name="teileid" value="'.$row['teileid'].'">
			  </div>

			  <div class="form-group">
				<label for="Anzahl">Anzahl</label>
				<input type="text" class="form-control" id="anzahl" name="anzahl" value="'.$row['anzahl'].'">
			  </div>			  
			  		  
			  <button type="submit" class="btn btn-primary">aktualisieren</button>
			  
			</form>
			<form name="" id="" method="post">
				<button type="submit" class="btn btn-primary">loeschen</button>
				<input type="hidden" id="todo" name="todo" value="loeschen">		
				<input type="hidden" id="repdetid" name="repdetid" value="'.utf8_encode($row['repdetid']).'">						
			</form>
		</div>	
	';
}

// -------------------------------------------------------------------------------------







// ------------ Kunde abfragen ---------------------------------------------------------
require('db_connect.php');

$sql='SELECT * FROM kunde';

	$kd = '<option name="kdfilter" id="kdfilter">&nbsp;</option>';

foreach($pdo->query($sql) as $row) {
	$kd .= '<option name="kdfilter" id="kdfilter">'.utf8_encode($row['kundennummer']).'</option>';	
//	$kd .= '<option name="kdfilter" id="kdfilter">'.utf8_encode($row['nachname']).' '.utf8_encode($row['vorname']).' '.utf8_encode($row['kundennummer']).'</option>';
}

if(count($_POST)) {
	if($_POST['kdfilter'] =! '') {
		$kd = '<option name="kdfilter" id="kdfilter">'.$_POST['kdfilter'].'</option>';	
	}
}
// -----------------------------------------------------------------------------------






// ========== LÖSCHEN =============

if (count($_POST)) {
	//print_r($_POST);

	if ($_POST['todo'] == 'loeschen') {
	
	$id = $_POST['repdetid'];
	
	echo 'Wollen Sie den Datensatz '.$id.' wirklich löschen?
		<form name="" id="" method="post">
			<input type="hidden" name="todo" id="todo" value="wirklich_loeschen">
			<input type="hidden" name="id" id="id" value="'.$id.'"> 
			<input type="submit" value="JA">
		</form>
	';

	echo '
		<form name="aktualisieren" id="aktualisieren" method="post">
			<input type="submit" value="NEIN">
		</form>
	';
	
	}
}



// ========== LÖSCHEN II =============

if (count($_POST)) {
	if ($_POST['todo'] == 'wirklich_loeschen') {
	
	$id = $_POST['id'];
	
	// --------------------------------------------------------------------

	require('db_connect.php');

	$statement = $pdo->prepare('DELETE FROM reparaturdetails WHERE repdetid = ?');

	$statement->execute(array($id));

	// -----------------------------------------------------------------------------------
	
	echo '<meta http-equiv="refresh" content="0">';	
		
	}
}



	






if (count($_POST)) {
	//print_r($_POST);

	if ($_POST['todo'] == 'aktualisieren') {
	
	echo '<meta http-equiv="refresh" content="0">';		
	}
}




$button_aktualisieren = '
	<form name="aktualisieren" id="aktualisieren" method="post">
		<input type="submit" value="Seite aktualisieren">
	</form>
';




?>

<?php include('head.php'); ?>

<?php include('navigation.php'); ?>




<div class="formulare">
	<form name="" id="" action="" method="post">
		<input type="hidden" id="todo" name="todo" value="eintragen">		

		<h1>Reparaturauftrag</h1>
	  
	  <div class="form-group">
		<label for="Datum">Datum</label>
		<input type="date" class="form-control" id="datum" name="datum" placeholder="">
	  </div>	  
	  
	  <div class="form-group">
		<label for="Teile">Teile</label>
		<input type="text" class="form-control" id="teile" name="teile" placeholder="">
	  </div>

	  <div class="form-group">
		<label for="Anzahl">Anzahl</label>
		<input type="number" class="form-control" id="anzahl" name="anzahl" placeholder="">
	  </div>
	  
	  <button type="submit" class="btn btn-primary">eintragen</button>
	  
	</form>
</div>


<!--
repid	fzid	datum
repdetid	repid	teileid	anzahl
-->



<div class="formulare">
<?php echo $ausgabe; ?>
</div>




</body>
</html>