<?php
$pdo = new PDO("mysql:host=localhost;dbname=kfzwerkstatt","root","");
?>